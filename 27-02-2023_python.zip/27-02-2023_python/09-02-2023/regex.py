#ex:
#my name is Raju my date of birth is 22-12-1992 and my email ID is abcd@gmail.com and pincode is 500082 and my vehicle number is AP16E1234
# str="my name is Raju my date of birth is 22-12-1992 "\
#     "and my email ID" \
#     "is abcd@gmail.com and pincode is 500082" \
#     "and my vehicle number is AP16E1234"
#to achieve this one there is a concept regex
#regex only for string
#regex inbuilt module
# import re
# print(dir(re))

#ex:1
# import re
# str="Python 1234 ABCD"
# result=re.findall("[0-9]",str)
# result=re.findall("[0-9]+",str)
# result=re.findall("[a-z]",str)
# result=re.findall("[A-Z]",str)
# result=re.findall("[A-Z,a-z]+",str)
# print(result)

#ex:2
# import re
# name="this is python training on 09022023 FEB"
# result=re.findall("[0-9:A-Z]+",name)
# print(result)

#'compile', 'copyreg', 'enum', 'error', 'escape', 'findall', 'finditer', 'fullmatch', 'functools',
# 'match', 'purge', 'search', 'split', 'sre_compile', 'sre_parse', 'sub', 'subn', 'template']

#ex:3
# import re
# name="This is python training"
# result=re.split(' ',name)
# print(result)

#ex:4
# import re
# url="https://www.google.com"
# res=re.split('\.',url)
# # print(res)
# if 'google' in res:
#     print(res,"found")
# else:
#     print("not found")

#ex:5:
# import re
# url="https://www.google.com"
# result=re.search('google',url)
# print(result)
# if 'google' in result:
#     print(result,"found")
# else:
#     print("not found")

#ex:6 replacement like substitue value
# import re
# url="https://www.google.com"
# result=re.sub('google','sri',url)
# print(result)

#ex:7:
# import re
# str="my name is Raju my date of birth is 22-12-1992 and my email ID is abcd@gmail.com " \
#     "and pincode is 500082 and my vehicle number is AP16E1234"
# result=re.search('date of birth',str)
# # result=re.findall('[0-9,a-z,A-Z,@]+',str)
# print(result)

#ex:8
# import requests
# url= "https://api.publicapis.org/entries"
# response = requests.get(url)
# print(response.status_code)

#ex:9:
# import requests
# url= "https://api.publicapis.org/entries"
# response = requests.get(url)
# result = response.json()
# for each in result.get('entries'):
#     print(each.get('API'),each.get('Description'),each.get('Auth'))








