#list is collection of different elements enclosed in square []
#example1
#num_list=[1,1.2,-1,2,3,'a']
#print(type(num_list))
#print(dir(num_list))

#'append', 'clear', 'copy', 'count', 'extend', 'index', 'insert', 'pop', 'remove', 'reverse', 'sort'

#ex:2
# num_list=[1,1.2,-1,2,3,'a']
# num_list.append('python')
# num_list.append('abc')
# print(num_list)
# print(len(num_list))

#ex:3
# num_list=[1,1.2,-1,2,3,'a']
# num_list.clear()
# print(num_list)

#'append', 'clear', 'copy', 'count', 'extend', 'index', 'insert', 'pop', 'remove', 'reverse', 'sort'
# ex:4
# num_list=[1,1.2,-1,2,3,'a']
# result=num_list.copy()
# print(num_list)
# print(result)

# ex:5
# num_list=[1,1.2,-1,2,3,'a',1,1]
# num_list.count(1)
# print(num_list.count(1))

# ex:6
# num_list=[1,1.2,-1,2,3,'a',1,1]
# string_list=['a','b','c','d']
# num_list.extend(string_list)
# print(num_list)

#index', 'insert', 'pop', 'remove', 'reverse', 'sort'
# # ex:7
# num_list=[1,1.2,-1,2,3,'a',1,1]
# num_list.index('a')
# print(num_list.index('a'))

#Note: index,count are not modifying.But insert,extend are modifying so passing to NUm_list
#ex:8
# num_list=[1,1.2,-1,2,3,'a',1,1]
# num_list.insert(2,34)
# print(num_list)

#ex:9
# num_list=[1,1.2,-1,2,3,'a',1,1]
# num_list.pop(0)
# print(num_list)

#ex:9
# num_list=[1,1.2,-1,2,3,'a',1,1]
# num_list.remove('a')
# print(num_list)

#ex:10
# num_list=[1,1.2,-1,2,3,'a',1,1]
# num_list.reverse()
# print(num_list)

#ex:11
# num_list=[1,-1,2,3,7,8,9,]
# num_list.sort()
# print(num_list)

#ex:12
# num_list=[]
# even_list=[]
# odd_list=[]
# for each in range(1,10):
#     num_list.append(each)
#     if (each%2)==0:
#         even_list.append(each)
#     else:
#         odd_list.append(each)
# print(num_list)
# print(even_list)
# print(odd_list)

#ex:13
# lst=[1,2,3,'a','aws','Devops',2.3,0.1,True]
# lst1=[]
# for each in lst:
#     if type(each)==str:
#         lst1.append(each)
# print(lst1)

#ex:14 (only a start names a and z start names
# names=['ram','arun','kumar','zebra','agra','zoo','krishna']
# a_names=[]
# z_names=[]
# diff_names=[]
# for each in names:
#     if each.startswith("a"):
#         a_names.append(each)
#     elif each.startswith('z'):
#         z_names.append(each)
#     else:
#         diff_names.append(each)
# print(a_names,':starts with alphabet a')
# print(z_names,':starts with alphabet z')
# print(diff_names,':starts with diff alpha')

#ex:15(only div by 3 and 5)
# list=[3,6,9,12,15,18,21,5,10,15,20,25,30,22,23]
# list_3=[]
# list_5=[]
# lst_diff=[]
# for each in list:
#     if each%3==0:
#         list_3.append(each)
#     elif each%5==0:
#         list_5.append(each)
#     else:
#         lst_diff.append(each)
# print(list_3,':div by 3')
# print(list_5,':div by 5')
# print(lst_diff,':div by diff values')


















