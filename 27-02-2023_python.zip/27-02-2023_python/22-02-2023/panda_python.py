#pip install pandas
#pip show pandas
# import pandas
# print(dir(pandas))

#ex:1
import pandas
pydic={'name':'sri','year':'2023','date':'22feb'}
df=pandas.DataFrame([pydic])
print(df)
df.to_csv('sample.csv')


