# import datetime
# print(dir(datetime))
import json

# 'MAXYEAR', 'MINYEAR,'date', 'datetime', 'datetime_CAPI', 'time', 'timedelta', 'timezone', 'tzinfo'

#ex:1
# from datetime import datetime
# print(datetime.now())

#ex:2
# import calendar
# print(calendar.calendar(2022))

#ex:3
# from datetime import date
# print(date.today())

#ex:4:
# import time
# # print(dir(time))
# print(time.localtime())

#ex:5
# import json
# a={'name':'python','year':'2023','date':'20thfeb'}
# file=open("sample.json","w")
# file.write(json.dumps(a,indent=4))



