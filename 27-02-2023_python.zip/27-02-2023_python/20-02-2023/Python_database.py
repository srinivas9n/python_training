# import mysql.connector as connector
# connection=connector.connect('root','password','localhost','movies')
# cursor=connection.cursor()
# query='select * from movie_info'
# cursor.execute(query)
# result=cursor.fetchall()
# print(result)

import mysql.connector as connector
import pandas as p
import pandas as pd

connection=connector.connect('root','password','localhost','movies')
cursor=connection.cursor()
query='select * from movie_info'
cursor.execute(query)
result=cursor.fetchall()
# print(result)
data_list =[]
for each in results:
    data = {}
    data["id"]=each[0]#ID,NAME,other things
    data["name"] = each[1]
    data["budget"] = each[2]
    data_list.append(data)
df=pd.DataFrame(data_list)
df.to_csv('movie.csv',index=False)


