#task:functions:we can define the logic multiple times.when we call we can fill there
#print("helloworld")
# def home():
#     print('hello world')
# home()
# home()
# home()

#built n functions and user defined function
#built in means print function,
#user defined means which is defined by user (ref above ex)
#in built functions means print,type,dir
#user defined functions are def key word to create any function
#ex:1
# def add(): #function defination
#     a=10
#     b=20
#     c=a+b
#     print(c)
# add()   #call the function

#ex:2
# def add(a,b):  #a,b are called as arguments
#     print(a+b)
# add(10,20)
# add(30,40)
# add(3,-2)

#ex:3 #multipication
# def multi(a):
#     print(a*3)
# multi(2)

#ex:4:
# def square(a):
#     print(a*a)
# square(4)

#ex:5:

# def name(a):
#     print(type(a))
# name("hello")
# name(2)

#ex:6: positive and negitive
# def num(a):
#     if a>=0:
#         print(a,":positive numbers")
#     else:
#         print(a,":negitive number")
# num(-7)

#ex:7: even or odd
# def num(a):
#     if a%2==0:
#         print(a,"even number")
#     else:
#         print(a,"odd number")
# num(3)
#Types of arguments:
#position arguments,default arguments,variable length argument,key word argument
#ex:8: positional argument
# def num(a,b):
#     c=a+b
#     print(c)
# num(2,3)

#ex:9: variable length argument example
# def num_list(*a):
#     print(a)
# num_list(1,2,3,[4,5,6,7,8,9])

#ex:10: variable length argument you can pass anything
# def num_string(*a):
#     print(a)
# num_string('ram','krishna',8,9)

#ex:11:default argument:
# def home(a=10,b=20):
#     print(a,b)
# home('hai',40)

#ex:12: keyword argument:
# def create(a,b,c):
#     print(a,b,c)
# create(a='python',b='devops',c={ 1:1,2:3})

#ex:13 remove negative values
# num_list=[23,17,22,0,-2,-3,-1]
# pos_val=[]
# neg_val=[]
# def num(*a):
#     for each in a:
#         if each>=0:
#             pos_val.append(each)
#         else:
#             neg_val.clear()
# num(23,17,22,0,-2,-3,-1)
# print(pos_val,"postive values")
# print(neg_val,"values clear")

# #ex:14 total sum
# def num(*number):
#     print(sum(number))
# num(1,2,3,4,5)

# #ex:15: print reverse order using with function
# def name(a):
#     print(reverse(a))
# name('Pythontraining'[::-1]) # start,step last checking

# list=[]
# def name(a):
#     for each in a:
#         list.append(each)
#         list.reverse()
# name('Pythontraining')
# print(list)


def name(s):
    str=""
    for i in s:
        print(i,"coming from loop")
        str=i+str
        print(str,"output")
name("pythontraining")














