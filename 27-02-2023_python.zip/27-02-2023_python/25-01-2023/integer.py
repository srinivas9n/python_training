# name="python"
# for each in name:
#     print(each)

# name="devops"
# for each in name:
#     print(each.upper())

# name="hello123"
# for each in name:
#     if each.isalpha():
#         print(each)

# for number in range(101):
#     if (number%2)==0:
#         print("even number",number)
#     else:
#         print("odd number",number)

# number=11
# for each in range(number):
#     if each%2==0:
#         print(each,"is div by 2")
#     elif each%3==0:
#         print(each,"is div by 3")
#     else:
#         print("not divide 2 or 3")

# name="python"
# for each in range(1,11):
#     print(name+str(each))
# for each in range(1,11):
#     url="http://books.toscrape.com/catalogue/category/books_1/page-{}.html".format(each)
#     print(url)
for each in range(11):
    if each==6:
        print(each)
        break














