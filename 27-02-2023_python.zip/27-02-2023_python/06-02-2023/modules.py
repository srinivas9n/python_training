#modules will refer the python files extension .py files
#collection of functions or group of functions is called modules
#Two types: built,user defined modules
#Built in modules
#ex:1
# import random
# # print(dir(random))
# for each in range(1,101):
#     x = random.randint(00000, 99999)
#     print(x)

#ex:2
# import os
# print(dir(os))
# print(os.getcwd())
# # print(os.mkdir('srikanth'))
# # print(os.rmdir('srikanth'))
# # print(os.listdir(os.getcwd()))
# print(os.listdir(R"C:\Users\ASUSSC\PycharmProjects\pythonProject")) #R will raw string will consider the nicodes

#ex:3
# import math
# print(dir(math))

# import json #will explain later for files

# #ex:4 (refer python_math,py_math)
# def add(a,b):
#     c=a+b
#     print(c)
# add(2,3)

#how to create the text files
#need only pdf files from download

# #example:
# x=open('srini.txt','r')
# y=open('srikanth.txt','r')

#ex:2:
# file=open("python.txt",'w')
# #print(dir(file))
# file.write("HelloWorld")

#ex:
# file=open("new.txt",'w')
# a="The following constants are options for the flags. They can be combined using the bitwise OR operator"
# file.write(a)

#ex:
# file=open("new.txt",'r')
# data=file.read()
# print(data)

#ex:
dict={}
file=open("aws.txt",'r')
# f1="This would create given file foo.txt and then would write given content in that file as would produce following result"
# f2=file.write(f1)
data=file.read()
word=data.split()
for t in word:
    dict[t]=word.count(t)
print(dict)
# if 'awcounts' in data:
#     print("aws is avail")
# else:
#     print("not avail")

#regex
#oops,packages,python with aws,exception handling,...examples
#project,database connectivity with python







