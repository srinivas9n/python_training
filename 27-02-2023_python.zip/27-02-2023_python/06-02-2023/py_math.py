import pytho_math
# print(dir(python_math))
pytho_math.add(1,5)