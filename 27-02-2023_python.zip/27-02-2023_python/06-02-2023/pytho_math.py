#ex:4
#need only pdf files from download
def add(a,b):
    c=a+b
    print(c)
