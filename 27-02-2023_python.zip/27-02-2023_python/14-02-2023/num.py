# from oops import number
# n1=number()
# n1.num_check(2)
# n1.even_odd(2)