# import boto3
# client=boto3.client('s3')
# print(dir(boto3))
# print(dir(client))

#'client','compat', 'docs', 'exceptions', 'logging',
# 'resource', 'resources', 'session', 'set_stream_logger', 'setup_default_session', 'utils'

# import boto3
# client=boto3.client('s3')
# response = client.create_bucket(
#     Bucket='am-training',
# )

#ex2:
# import boto3
# s3 = boto3.resource('s3')
# s3.meta.client.upload_file('business-financial-data-september-2022-quarter.csv', 'am-training', 'hello.csv')

#ex:3:create 10 files through python and upload into s3 bucket
# import boto3
# s3 = boto3.resource('s3')
# files=["python.txt", "Devops.txt","aws.txt","dir.pdf","console.csv","sample.jpg"]
# for each in files:
#     filename = open(each,"w")
#     # filename=open("python"+str(each)+".txt",'w')
#     print(filename)
#     s3.meta.client.upload_file(each,'am-training',each)

#delete files,delete bucket
#ex:4
# import boto3
# s3 = boto3.resource('s3')
# s3.meta.client.download_file('am-training', 'hello.csv', 'test.csv')

import boto3
s3 = boto3.resource('s3')
bucket=s3.Bucket('am-training')
for each in bucket.objects.all():
    print(each.key)
    s3.meta.client.download_file(each.key,'am-training',each.key)

# filenames = []
# result = s3.list_objects(Bucket="am-training")
# for item in result['Contents']:
#         files = item['Key']
#         print(files)
#s3.meta.client.download_file('am-training',,'python.txt')


#create a folder in bucket
# import boto3
# s3 = boto3.resource('s3')
# s3.meta.client.upload_file('business-financial-data-september-2022-quarter.csv', 'am-training', 'csv_files/hello.csv')
