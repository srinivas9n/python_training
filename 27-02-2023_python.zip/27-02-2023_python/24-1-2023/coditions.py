#PANCARD number length
#pancard_no="ABCD12345"
#if len(pancard_no)==10:
#    print("Valid pancard number")
#else:
#    print("Invalid pancard number")

#if condition1:
    #acton1
#elif condition2:
    #action2
#else:
    #action3

#
# name=20+0.0
# if type(name)==str:
#     print("string type")
# elif type(name)==int:
#     print("integer type")
# else:
#     print("Not int or not string")


# num=12
# if num>0:
#     print("positive number")
# elif num<0:
#     print("negative number")
# else:
#     print("Not Positive NOt negative")

# name="Wikipedia is a free online encyclopedia, created and edited by volunteers around the world"
# word="free"
# if word in name:
#     print("result found")
# else:
#     print("result not found")

#task:marks grade
# marks=300
# if marks>=360:
#     print("A grade")
# elif marks>=300:
#     print("B grade")
# else:
#     print("C grade")

#area of rectangle
w=10
h=20
Area=w*h
print(Area)

#parimeter of rectangle

l=10
b=20
parimeter=2*(l+b)
print(parimeter)
