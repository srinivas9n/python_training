a="Ram"
if a=="Ram":
    print('a value is true')
else:
    print('a value is false')

a=-10
if a>=0:
    print('positive value')
else:
    print('negative val')

