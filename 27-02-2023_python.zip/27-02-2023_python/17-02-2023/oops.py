#oops
#class & obj
#class is a
# class student:
#     print("student")
# stu=student
# print(stu)
# print(dir(stu))

ex:1
# class student:
#     def fullname(self,firstname,lastname):
#         print(firstname+lastname)
# stu=student()
# stu.fullname("srinivas","reddy")
# print(stu)
# print(dir(stu))
#ex:
# name="python"
# print(name.upper())

#ex:3
# class section:
#     def rollnumber(self,number):
#         print(number)
# sect=section()
# sect.rollnumber(11223456)
# print(dir(sect))

#ex:4
# class number:
#     def num_check(self,num):
#         if num>=0:
#             print("positive number")
#         else:
#             print("negitive number")
#     def even_odd(self,num):
#         if num%2==0:
#             print("even number")
#         else:
#             print("odd number")

#refer num.py for calling function

#how to create the variables
#how to connect the db from python
#inheritance
#ex:
# class A:
#     print("I am classA")
# class B(A):
#     print("I am classB")
# obj=B()
# print(obj)

#ex:Create a class 'rectangle' area&paremter
# class rectangle:
#     def area(self,length,breadth):
#         print(length*breadth)
#     def perimeter(self,length,breadth):
#         print(2*(length*breadth))
# a1=rectangle()
# a1.area(2,3)
# a1.perimeter(3,6)
#ex:Create a class 'check obj type' s integer or string
# class num:
#     def diff(self,a):
#         if type(a)==str:
#             print(a,"string value")
#         else:
#             print(a,"int value")
#
# n1=num()
# n1.diff("srisri")

#ex:
# list1=[1,2,3,2,1,5,6]
# result=[]
# for each in list1:
#     if each not in result:
#         result.append(each)
#     else:
#         print(each)
# print(result)

#ex:get numbers chars and special charas in diff list
# name="abcd@123"
# stroutput=[]
# intoutput=[]
# spcharsout=[]
# for each in name:
#     if each.isalpha():
#         stroutput.append(each)
#     elif each.isdigit():
#         intoutput.append(each)
#     else:
#         spcharsout.append(each)
# print(stroutput)
# print(intoutput)
# print(spcharsout)

#ex:
# num=[1,2,3,4,5,6,7,8,9,10]
# a1=[]
# b1=[]
# result={}
# for each in num:
#     if each%2!=0:
#         a1.append(each)
# result["num"]=a1
# print(result)

#database programming,3 mini projects,polymorphisum
# ls1=[1,2,3,4,5]
# ls2=["a","b","c","d"]
# #create dict
# print(dict(zip(ls1,ls2)))

#count the files txt & pdf on target folder
#All the files from folders move to dest folders
#copy files from one folder to another folder
# import shutil
# # shutil.copy("num.py",r"C:\Users\ASUSSC\PycharmProjects\pythonProject\14-02-2023")
# shutil.move("file.txt",r"C:\Users\ASUSSC\PycharmProjects\pythonProject\14-02-2023")
