elgage=18
if elgage>=18:
    print("your elgible")
else:
    print("not elgible")