#dictionary is key,value pair enclosed in {}
#ex:1
# py_dict={'name':'Krishna','age':23,'role_num':11}
# print(py_dict)
# print(dir(py_dict))
# print(type(py_dict))

#clear', 'copy', 'fromkeys', 'get', 'items', 'keys', 'pop', 'popitem', 'setdefault', 'update', 'values'
# ex:2
# py_dict={'name':'Krishna','age':23,'role_num':11}
# py_dict.clear()
# print(py_dict)

# ex:3
# py_dict={'name':'Krishna','age':23,'role_num':11}
# res=py_dict.copy()
# print(res)


# ex:4
# py_dict={'name':'Krishna','age':23,'role_num':11}
# print(py_dict.fromkeys('name'))

ex:5
# py_dict={'name':'Krishna','age':23,'role_num':11}
# res=py_dict.copy()
# print(res)


#ex:6
# py_dict={'name':'Krishna','age':23,'role_num':11}
# print(py_dict.get('age'))

#ex:7
# py_dict={'name':'Krishna','age':23,'role_num':11,'class':'10th'}
# print(py_dict.keys())
# print(py_dict.values())
# # print(py_dict.pop('name'))
# print(py_dict.popitem())
# print(py_dict)

#ex:8
# py_dict={'name':'Krishna','age':23,'role_num':11,'class':'10th'}
# py_dict['address']='Hyderabad'
# print(py_dict)
# py_dict.update({'location':'Kukatpally'})
# print(py_dict)
# print(len(py_dict))

#ex:9
# py_dict={'name':'Krishna','age':23,'role_num':11,'class':'10th'}
# print(py_dict.items())

#ex:10
# py_dict={'name':'Krishna','age':23,'role_num':11,'class':'10th'}
# py_dict.setdefault('name','abcd@gmail.com')
# print(py_dict)

#ex:11: one one value IMPP
# name='sudhakar'
# ex_dict={}
# for each in name:
#     ex_dict[each]=name.count(each)
# print(ex_dict)

#     # print(py_dict.fromkeys('name'))
#ex:12: empty dictionary:name,dob,age add it in name
# info={}
# info.update({'name':'Ram'})
# info.update({'dob':'31-01-2022'})
# info.update({'age':'31'})
# print(info)

