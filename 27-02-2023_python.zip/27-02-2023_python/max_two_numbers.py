#num1 = int(input("Enter the first number: "))
#num2 = int(input("Enter the second number: "))

#if(num1 > num2):
#  print(num1, "is greater")
#elif(num1 < num2):
#    print(num2, "is greater")
#else:
#    print("Both are equal")

a=10
b=20
if a>b:
    print("a is greater")
else:
    print("b is greater")