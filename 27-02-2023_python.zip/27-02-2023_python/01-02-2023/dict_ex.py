#ex:1
# ex_dict={'name':'python','duration':'20 days','year':'1993'}
# key='year'
# if key in ex_dict:
#     print("found :" +ex_dict.get(key))
# else:
#     print("not found")

#functions,
# modules:in-built modules,user define,regular modules
# oops,


