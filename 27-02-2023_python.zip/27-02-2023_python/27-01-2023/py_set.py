#set is collection elements which is encolsed in {}
#ex:1
# num_set={1,2,3,4}
# print(type(num_set))
# print(dir(num_set))

#'add', 'clear', 'copy', 'difference', 'difference_update', 'discard', 'intersection', 'intersection_update',
# 'isdisjoint', 'issubset',issuperset', 'pop', 'remove', 'symmetric_difference', 'symmetric_difference_update',
# 'union', 'update'
#Set:order is not reserverd (inorder) compare to tuple,list.
#set is not allowing duplicates
#elements in inorder

#ex:2
#num_set={1,2,3,4}
# num_set.add('python')
# print(num_set)
#clear
# num_set.clear()
# print(num_set)

# num_set.copy()
# print(num_set)

#bydefault will remove the 1st argument in set
# num_set={1,2,3,4}
# num_set.pop()
# print(num_set)

# num_set={1,2,3,4}
# num_set.remove(4)
# print(num_set)

#ex:4
# num_set1={1,2,3,4}
# num_set2={4,5,6,7}
# print(num_set1.difference(num_set2))
# print(num_set2.difference(num_set1))

#ex:5
# num_set1={1,2,3,4}
# num_set2={4,5,6,7}
# print(num_set1.intersection(num_set2))
# print(num_set1.union(num_set2))

#ex:6
# num_set1={1,2,3,4}
# num_set2={1,2,3,4}
# # print(num_set1.issuperset(num_set2))
# print(num_set1.issubset(num_set2))

#ex:7
# name="ramu"
# print(list(name))
# print(tuple(name))
# print(set(name))

#ex:8
# name="raju"
# result=set()
# result.add(name)
# print(result)

#ex:9
# result=set()
# for each in range(1,11):
#     result.add(each)
# print(result)


#ex:10
# name="Whether yo're new to Git or a seasoned ser, GitHub Desktop simplifies yor development workflow"
# result=set()
# vowels=('a','e','i','o','u')
# for each in vowels:
#     if each in name:
#         result.add(each)
# print(result)

# ex:11: do in list
# name="Whether yo're new to Git or a seasoned ser, GitHub Desktop simplifies yor development workflow"
# result=set()
# vowels=('a','e','i','o','u')
# for each in vowels:
#     if each in name:
#         result.add(each)
# print(list(result))
# ex:12:remove duplicate elements from list
# name = { 1,2,3,2,1,3,5 }
# print(list(name))

#count of vowels:
# name="Whether youre new to Git or a seasoned ser, GitHub Desktop simplifies yor development workflow"
# result=set()
# vowels=('a','e','i','o','u')
# for each in vowels:
#     if each in name:
#         print(each,name.count(each))
#         result.add(each)
# print(list(result))

#not vowles:
# name="Whether youre new to Git or a seasoned ser, GitHub Desktop simplifies yor development workflow"
# result=set()
# vowels=('a','e','i','o','u')
# for each in name:
#     if each not in vowels:
#         print(each,name.count(each))
#     else:
#         print(each,name.count(each))


