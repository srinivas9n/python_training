#Tuple: collection of elements which are enclosed in () parenthasis
#ex:1
# num_tuple=(1,2,3)
# print(type(num_tuple))
# print(dir(num_tuple))
#
# 'count', 'index
#note:list is changeable,tuple not changable
#ex:2
# num_tuple=(1,2,3,2,4,2,5,6,2)
# print(num_tuple.count(2))
# print(num_tuple.index(6))

#ex:3:Type conversion
# name="Datascience"
# print(list(name))
# print(tuple(name))

#ex:4
# x=10
# print(type(x))
# y=str(x)
# print(y,type(y))

#ex:5:cannot covert names and able to convert numbers
# x='zoom'
# print(int(x))









